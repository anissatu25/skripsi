<?php
    error_reporting(0);
    session_start();
  include  "../config/koneksi.php";
   $nama = $_SESSION['username'];
   $user_level = $_SESSION['level'];
  if(!isset($_SESSION['username'])){
  
    header('location:index.php');
  }

// header("Content-type: application/vnd-ms-excel");
//   header("Content-Disposition: attachment; filename=Data Hasil Voting.xls");
    switch($_GET[act]){
       default:
       ?>



                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box card shadow">
                                        
                                        <div class="card-body">

                                         <center>
                                          <table>
                                            <tr>
                                              <th><img src="../assets/img/pemilihan.png" width="150px"></th>

                                              <th> <h2><b>UNIVERSITAS ISLAM KUANTAN SINGINGI</b></h2>
                                              Komplek Universitas Islam Kuantan Singingi<br/>
                                              Jl. Gatot Subroto KM 7 Teluk Kuantan Telp . 0760-5555/0855xxx32111
                                              <br/>





                                            </th>
                                            </tr>
                                          </table>
                                          </center>
                                          <hr width="100%" align="center" />

                                            <center><b>BERITA ACARA</b><br/>

                                               
                                              <p>Pada Hari ini :............. Tanggal ........... tahun ........</p><br/>
                                               </center>
                                              <table>
                                                <tr>
                                                  <th>Pukul</th>
                                                   <th>:</th>
                                                   <th>.............</th>
                                                </tr>
                                                 <th>Tempat</th>
                                                   <th>:</th>
                                                   <th>.............</th>
                                                <tr>
                                                  
                                                </tr>
                                              </table>

                                              <p>Telah dilahksanakan pemilihan..........................</p><br/>

                                             <p>Universitas Islam Kuantan Singingi dengan hasil sebagai berikut :</p>

                                          

                                         

                                          

                                         


                                        
                        <table border="1" cellspacing="0" cellpadding="0" width="100%">
                          <thead>
                            <tr>
                              <th class="wd-15p">No</th>
                             
                              <th class="wd-15p">Kandidat</th>
                              <th class="wd-20p">Jumlah Voting</th>
                              <th class="wd-20p">Keterangan</th>
                             
                            </tr>
                          </thead>
                          <tbody>

                            <?php
                            $query=mysql_query("select count(a.idkandidat) as total,b.nama from votingkandidat a left join v_user b on a.idkandidat=b.id where b.id_level='3' group by a.idkandidat");
                            $no;
                            while ($q=mysql_fetch_array($query)) {
                              $no++;
                             

                             echo "
                              <tr>
                              <td>$no</td>
                                
                                <td>$q[nama]</td>
                                <td>$q[total] </td>
                                  <td> </td>
                              </tr>";



                              
                            }


                            ?>
                          <!--   <tr>
                              <td>Bella</td>
                              <td>Chloe</td>
                              <td>System Developer</td>
                              <td>2018/03/12</td>
                              <td>$654,765</td>
                              <td>b.Chloe@datatables.net</td>
                            </tr> -->
                          
                          </tbody>
                        </table>
                </div>

                <br/>

                <center><p>Mengetahui</p><br/>
                  <b>Komisi Pemilihan Umum Mahasiswa</b><br/>

                  <b>Universitas Islam Kuantan Singingi Tahun</b>
                  <br/><br/><br/>

                  <table>
                    <tr>
                      <th width="25%">Ketua KPUM</th>
                      <th width="25%">Sekertaris</th>
                    </tr>
                  </table>

                  <br/> <br/> <br/>

                   <table>
                    <tr>
                      <th width="25%">Muhammad Abrar <br/> <hr/>NPM. 1500000</th>
                      <th width="25%">Iron Agus. S <br/><hr/> NPM. 1555555</th>
                    </tr>
                  </table>


                </center> <br/> <br/> <br/>


       <?php
        break;
      

    
    }

?>



              