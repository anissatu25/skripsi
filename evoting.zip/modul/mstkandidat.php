<?php
    error_reporting(0);
    session_start();
  include  "config/koneksi.php";
   $nama = $_SESSION['username'];
   $user_level = $_SESSION['level'];
  if(!isset($_SESSION['username'])){
  
    header('location:index.php');
  }

 //simpan
    if (isset($_POST['submit'])) {

    

              $target_dir = "assets/foto/";
              $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
              $uploadOk = 1;
              $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
              // Check if image file is a actual image or fake image
              if(isset($_POST["submit"])) {
                  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
                  if($check !== false) {
                      echo "File is an image - " . $check["mime"] . ".";
                      $uploadOk = 1;
                  } else {
                      echo "File is not an image.";
                      $uploadOk = 0;
                  }
              }
              // Check if file already exists
              if (file_exists($target_file)) {
                  
        echo "<script>window.alert('File sudah ada !!!')
        window.location='media.php?module=mstkandidat'</script>";
                  $uploadOk = 0;
              }
              // Check file size
              if ($_FILES["fileToUpload"]["size"] > 500000) {
                 
 echo "<script>window.alert('File terlalu besar !!!')
        window.location='media.php?module=mstkandidat'</script>";
                  $uploadOk = 0;
              }
              // Allow certain file formats
              if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
              && $imageFileType != "gif" ) {

               echo "<script>window.alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed. !!!')
                      window.location='media.php?module=mstkandidat'</script>";
                 
                  $uploadOk = 0;
              }
              // Check if $uploadOk is set to 0 by an error
              if ($uploadOk == 0) {
                  echo "<script>window.alert('Sorry, your file was not uploaded. !!!')
                      window.location='media.php?module=mstkandidat'</script>";
               
              // if everything is ok, try to upload file
              } else {
                  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {

                     echo "<script>window.alert('Foto berhasil disimpan. !!!')
                      window.location='media.php?module=mstkandidat'</script>";

                      $brkas=$_FILES['fileToUpload']['name'];

                     $cekusername=mysql_num_rows(mysql_query("SELECT * from user where username='$_POST[username]'"));

      if ($cekusername<1) {
         $password=md5($_POST[password]);
      mysql_query("INSERT INTO user ( `username`, `password`, `nama`, `id_level`,`alamat`,`phone`,`TanggalBuat`,`Foto`,`ktp`,`wakil`,`ktp2`) values ('$_POST[username]','$password','$_POST[nama]','$_POST[level]','$_POST[alamat]','$_POST[phone]',NOW(),'$brkas','$_POST[ktp]','$_POST[wakil]','$_POST[ktp2]')");


 echo "<script>window.alert('Penambahan User Berhasil !!!')
                                                window.location='media.php?module=mstuser'</script>";
      }else{
         
 echo "<script>window.alert('Gagal,username sudah ada!!')
                                                window.location='media.php?module=mstuser'</script>";

      }
                      
                  } else {
                     echo "<script>window.alert('Sorry, there was an error uploading your file. !!!')
                      window.location='media.php?module=mstkandidat'</script>";
                     
                  }
              }

    
    }elseif ($_GET[delete]=="y") {
      mysql_query("DELETE FROM `user` WHERE id='$_GET[id]'");

      header('location:media.php?module=mstkandidat');
    }elseif (isset($_POST[simpanedit])) {

     



     mysql_query("UPDATE `user` SET `nama`='$_POST[nama]',`phone`='$_POST[phone]',`alamat`='$_POST[alamat]',`ktp`='$_POST[ktp]',`wakil`='$_POST[wakil]',`ktp2`='$_POST[ktp2]' WHERE username='$_POST[username]'");
echo '<script type="text/javascript">
           window.location = "media.php?module=mstkandidat"
      </script>';
     
    }


    switch($_GET[act]){
       default:
       ?>



                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box card shadow">
                                        
                                        <div class="card-body">

                                          <h2 class="mb-0">Master Kandidat</h2>
                                           <hr/>

                                           <button type="button" class="btn btn-sm btn-primary mt-1 mb-1" data-toggle="modal" data-target="#largeModal">Tambah Data</button><br/><br/>


                                           <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered w-100 text-nowrap">
                          <thead>
                            <tr>
                              <th class="wd-15p">No</th>
                              <th class="wd-15p">No Identitas</th>
                             
                              <th class="wd-15p">Username</th>
                              <th class="wd-20p">Nama</th>
                              <th class="wd-15p">Level</th>
                                  <th class="wd-15p">Foto Kandidat</th>
                                     <th class="wd-15p">Wakil</th>
                         <th class="wd-10p">Aksi</th>
                            </tr>
                          </thead>
                          <tbody>

                            <?php
                            $query=mysql_query("SELECT * from v_user where id_level='3'");
                            $no;
                            while ($q=mysql_fetch_array($query)) {
                              $no++;
                             

                             echo "
                              <tr>
                              <td>$no</td>
                                  <td>$q[ktp]</td>
                                <td>$q[username]</td>
                                <td>$q[nama] </td>
                                <td>$q[NamaLevel] </td>
                                ";

                                ?>

                                    <td><a href="" onclick="gambar('assets/foto/<?php echo $q[Foto] ?>')" data-toggle="modal" data-target="#ambilgambar"><center><img src="assets/foto/<?php echo $q[Foto] ?>" width='100px'></center></a></td>
                                <?php
                                
                                echo"<td>$q[wakil] </td> <td>
                                <a href=\"media.php?module=mstkandidat&act=edit&id=$q[id]\" ><span class=\"badge badge-warning\">Edit</span></a>
                                <a href=\"media.php?module=mstkandidat&delete=y&id=$q[id]\" ><span class=\"badge badge-danger\">Hapus</span></a>
                                 </td>
                              </tr>";



                              
                            }


                            ?>
                          <!--   <tr>
                              <td>Bella</td>
                              <td>Chloe</td>
                              <td>System Developer</td>
                              <td>2018/03/12</td>
                              <td>$654,765</td>
                              <td>b.Chloe@datatables.net</td>
                            </tr> -->
                          
                          </tbody>
                        </table>
                </div>

                  <div class="modal fade" id="ambilgambar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h2 class="modal-title" id="largeModalLabel">Foto Kandidat</h2>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">

                                      
                        <p id="gbr" align="center" ></p>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                      </div>
                    </div>
                  </div>
                </div>

                  <div class="modal fade" id="largeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h2 class="modal-title" id="largeModalLabel">Tambah User</h2>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">

                      <form method="post" action="" enctype="multipart/form-data">


                          <div class="form-group">
                            <label class="form-label">Nama Ketua</label>
                            <input type="text" class="form-control"  placeholder="Nama" name="nama">
                          </div>
                            <div class="form-group">
                            <label class="form-label">No Identitas</label>
                            <input type="text" class="form-control"  placeholder="ktp" name="ktp" value="<?php echo $edit[ktp]; ?>">
                          </div>
                           <div class="form-group">
                            <!-- <label class="form-label">Username</label> -->
                            <input type="hidden" class="form-control"  placeholder="Username" name="username" >
                          </div>
                           <div class="form-group">
                            <!-- <label class="form-label">Password</label> -->
                            <input type="hidden" class="form-control"  placeholder="Password" name="password">
                          </div>

                          <div class="form-group">
                            <label class="form-label">Alamat</label>
                            <input type="text" class="form-control"  placeholder="Alamat" name="alamat" >
                          </div>

                          <div class="form-group">
                            <label class="form-label"> Nama Wakil</label>
                            <input type="text" class="form-control"  placeholder="Wakil" name="wakil" value="<?php echo $edit[wakil]; ?>">
                          </div>
                           <div class="form-group">
                            <label class="form-label">ktp</label>
                            <input type="text" class="form-control"  placeholder="ktp" name="ktp2" value="<?php echo $edit[ktp2]; ?>">
                          </div>

                          <div class="form-group">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control"  placeholder="Phone" name="phone" >
                          </div>
                          


                                             <div class="form-group">
                                                <label for="cc-number" class="control-label mb-1">Level</label>
                                                <?php
                                                 
                     
                    $sql = mysql_query("SELECT * from user_level where id='3'");
                      echo "<select class=\"form-control\" name=\"level\" required>";
                      
                    while ($r = mysql_fetch_array($sql)) {
                          
                        if ($tampil[Nama]==$r[level]) {
                        echo "<option value='$r[id]' selected>  $r[level] </option>";
                             }else{
                        echo "<option value='$r[id]'>  $r[level] </option>";
                              } 
                          }
                  
                         
                    echo '</select>';
    
                    ?>
                                               
                                            </div>
                  
                   
   <div class="form-group">
                            <label class="form-label">Pilih Foto Kandidat</label><br/>
                            <input type="file" name="fileToUpload" id="fileToUpload">
                          </div>
                     

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                      <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
                     
                    </div>
                  </div>
                </div>
              </div>
               </form>

       <?php
        break;
      

      case 'edit':
      $edit=mysql_fetch_assoc(mysql_query("SELECT * from v_user WHERE id='$_GET[id]'"));

     

        ?>

        

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box card shadow">
                                        
                                        <div class="card-body">

                                          <h2 class="mb-0">Edit</h2>
                                           <hr/>
                      <form method="post" action="" enctype="multipart/form-data">
                          <div class="form-group">
                            <label class="form-label">Nama Ketua</label>
                            <input type="text" class="form-control"  placeholder="Nama" name="nama" value="<?php echo $edit[nama]; ?>">
                          </div>
                            <div class="form-group">
                            <label class="form-label">No Identitas</label>
                            <input type="text" class="form-control"  placeholder="ktp" name="ktp" value="<?php echo $edit[ktp]; ?>">
                          </div>
                           <div class="form-group">
                            <!-- <label class="form-label">Username</label> -->
                            <input type="hidden" class="form-control" readonly  placeholder="Username" name="username" value="<?php echo $edit[username]; ?> ">
                          </div>
                          <div class="form-group">
                            <label class="form-label">Alamat</label>
                            <input type="text" class="form-control"  placeholder="Alamat" name="alamat" value="<?php echo $edit[alamat]; ?>">
                          </div>
                            <div class="form-group">
                            <label class="form-label">Wakil</label>
                            <input type="text" class="form-control"  placeholder="Wakil" name="wakil" value="<?php echo $edit[wakil]; ?>">
                          </div>
                          <div class="form-group">
                            <label class="form-label">ktp</label>
                            <input type="text" class="form-control"  placeholder="ktp" name="ktp2" value="<?php echo $edit[ktp2]; ?>">
                          </div>

                          <div class="form-group">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control"  placeholder="Phone" name="phone" value="<?php echo $edit[phone]; ?>">
                          </div>
                         
                          


                                             <div class="form-group">
                                                <label for="cc-number" class="control-label mb-1">Level</label>
                                                <?php
                                                 
                     
                    $sql = mysql_query("SELECT * from user_level where id='3'");
                      echo "<select class=\"form-control \" name=\"level\" readonly>";
                      
                    while ($r = mysql_fetch_array($sql)) {
                          
                        if ($edit[id_level]==$r[id]) {
                        echo "<option value='$r[id]' selected>  $r[level] </option>";
                             }else{
                        echo "<option value='$r[id]'>  $r[level] </option>";
                              } 
                          }
                  
                         
                    echo '</select>';
    
                    ?>
                                               
                                            </div>

                                                <div class="form-group">
                            <label class="form-label">Pilih Foto Kandidat</label><br/>
                            <input type="file" name="fileToUpload" id="fileToUpload">
                          </div>
                     


                    <button type="submit" name="simpanedit" class="mt-2 btn btn-block btn-success mt-1 mb-1">Simpan</button>
               </form>

        <?php
        break;
    
    }

?>



      
<script language="javascript" type="text/javascript">
  function gambar(gambarnya){
    var maincontent = "";
    maincontent = "<p><img src='" + gambarnya + "' width=\"600px\"></p>";
    document.getElementById("gbr").innerHTML = maincontent;
  }
</script>        