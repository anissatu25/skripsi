<?php
    error_reporting(0);
    session_start();
  include  "config/koneksi.php";
   $nama = $_SESSION['username'];
   $user_level = $_SESSION['level'];
  if(!isset($_SESSION['username'])){
  
    header('location:index.php');
  }

?>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>


<style type="text/css">
  #container {
  min-width: 320px;
  max-width: 600px;
  margin: 0 auto;
}
</style>
<?php
    switch($_GET[act]){
       default:
       ?>



                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box card shadow">
                                        
                                        <div class="card-body">

                                          <h2 class="mb-0">Grafik Hasil</h2>
                                           <hr/>

<div id="container"></div>


<hr/>



<?php
  $q=mysql_query("select count(a.idkandidat) as total,b.nama from votingkandidat a left join v_user b on a.idkandidat=b.id where b.id_level='3' group by a.idkandidat");

  while ($d=mysql_fetch_array($q)) {
    $a[]=$d[nama];
    $b[]=$d[total];
  }

  $c=json_encode($b);
  $d=str_replace('"', '', $c);

?>


<script type="text/javascript">
  var chart = Highcharts.chart('container', {

    title: {
        text: 'Grafik Hasil Vooting Kandidat'
    },

    subtitle: {
        text: 'Total Perolehan Suara'
    },

    xAxis: {
        categories: <?php echo json_encode($a); ?>
    },

    series: [{
        type: 'column',
        colorByPoint: true,
        data: <?php echo $d;?>,
        showInLegend: false
    }]

});


$('#plain').click(function () {
    chart.update({
        chart: {
            inverted: false,
            polar: false
        },
        subtitle: {
            text: 'Plain'
        }
    });
});

$('#inverted').click(function () {
    chart.update({
        chart: {
            inverted: true,
            polar: false
        },
        subtitle: {
            text: 'Inverted'
        }
    });
});

$('#polar').click(function () {
    chart.update({
        chart: {
            inverted: false,
            polar: true
        },
        subtitle: {
            text: 'Polar'
        }
    });
});



</script>











<?php
  $qe=mysql_query("select count(a.idkandidat) as total,c.Fakultas as nama from votingkandidat a left join v_user
 b on a.userpilih=b.username
left join fakultas c on b.id_fakultas=c.id_fakultas
  where b.id_level='2' group by c.id_fakultas");

  while ($d=mysql_fetch_array($qe)) {
    $aa[]=$d[nama];
    $bb[]=$d[total];
  }

  $cc=json_encode($bb);
  $dd=str_replace('"', '', $cc);

?>


<script type="text/javascript">
  var chart = Highcharts.chart('container2', {

    title: {
        text: 'Grafik Hasil Vooting Kandidat'
    },

    subtitle: {
        text: 'Total Perolehan Suara'
    },

    xAxis: {
        categories: <?php echo json_encode($aa); ?>
    },

    series: [{
        type: 'column',
        colorByPoint: true,
        data: <?php echo $dd;?>,
        showInLegend: false
    }]

});


$('#plain2').click(function () {
    chart.update({
        chart: {
            inverted: false,
            polar: false
        },
        subtitle: {
            text: 'Plain'
        }
    });
});

$('#inverted2').click(function () {
    chart.update({
        chart: {
            inverted: true,
            polar: false
        },
        subtitle: {
            text: 'Inverted'
        }
    });
});

$('#polar2').click(function () {
    chart.update({
        chart: {
            inverted: false,
            polar: true
        },
        subtitle: {
            text: 'Polar'
        }
    });
});

</script>





<?php
}



