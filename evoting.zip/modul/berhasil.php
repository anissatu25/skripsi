<?php
session_start();
  include"config/koneksi.php";
   $nama = $_SESSION['username'];
   $user_level = $_SESSION['user_level'];
  if(!isset($_SESSION['username'])){
  
    header('location:login.php');
    error_reporting(0);
  }

?>
  <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box card shadow">
                                        
                                        <div class="card-body">
  <center><img src="assets/img/pemilihan.png" width="200px"></center><br/>
          <span class="login100-form-title"><h2>
          Aplikasi Pemilihan Kandidat</h2><hr/>

        </span>
      </div>
    </div>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>


<style type="text/css">
  #container {
  min-width: 320px;
  max-width: 600px;
  margin: 0 auto;
}
</style>
<?php
    switch($_GET[act]){
       default:
       ?>



                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box card shadow">
                                        
                                        <div class="card-body">

                                          <h2 class="mb-0">Grafik Hasil Voting</h2>
                                           <hr/>

<div id="container"></div>

  <button type="button" class="btn btn-sm btn-primary mt-1 mb-1" id="plain">Plain</button>
    <button type="button" class="btn btn-sm btn-danger mt-1 mb-1" id="inverted">Inverted</button>
      <button type="button" class="btn btn-sm btn-warning mt-1 mb-1" id="polar">Polar</button>



<?php
  $q=mysql_query("select count(a.idkandidat) as total,b.nama from votingkandidat a left join v_user b on a.idkandidat=b.id where b.id_level='3' group by a.idkandidat");

  while ($d=mysql_fetch_array($q)) {
    $a[]=$d[nama];
    $b[]=$d[total];
  }

  $c=json_encode($b);
  $d=str_replace('"', '', $c);

?>


<script type="text/javascript">
  var chart = Highcharts.chart('container', {

    title: {
        text: 'Grafik Hasil Vooting Kandidat'
    },

    subtitle: {
        text: 'Total Perolehan Suara'
    },

    xAxis: {
        categories: <?php echo json_encode($a); ?>
    },

    series: [{
        type: 'column',
        colorByPoint: true,
        data: <?php echo $d;?>,
        showInLegend: false
    }]

});


$('#plain').click(function () {
    chart.update({
        chart: {
            inverted: false,
            polar: false
        },
        subtitle: {
            text: 'Plain'
        }
    });
});

$('#inverted').click(function () {
    chart.update({
        chart: {
            inverted: true,
            polar: false
        },
        subtitle: {
            text: 'Inverted'
        }
    });
});

$('#polar').click(function () {
    chart.update({
        chart: {
            inverted: false,
            polar: true
        },
        subtitle: {
            text: 'Polar'
        }
    });
});

</script>


<?php
}

