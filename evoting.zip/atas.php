<!DOCTYPE html>
<html lang="en" dir="ltr">

<!-- Mirrored from spruko.com/demo/ansta/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 18 Dec 2018 01:26:47 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
    <meta name="author" content="Creative Tim">

    <!-- Title -->
    <title>Pemilihan Kandidat
</title>
    <link href="assets/img/brand/favicon.png" rel="icon" type="image/png">
   
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800" rel="stylesheet">

    <!-- Icons -->
    <link href="assets/css/icons.css" rel="stylesheet">

    <!--Bootstrap.min css-->
    <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">

    <!-- Ansta CSS -->
    <link href="assets/css/dashboard.css" rel="stylesheet" type="text/css">

    <!-- Tabs CSS -->
    <link href="assets/plugins/tabs/style.css" rel="stylesheet" type="text/css">

    <!-- jvectormap CSS -->
    <link href="assets/plugins/jvectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />

    <!-- Custom scroll bar css-->
    <link href="assets/plugins/customscroll/jquery.mCustomScrollbar.css" rel="stylesheet" />

    <!-- Sidemenu Css -->
    <link href="assets/plugins/toggle-sidebar/css/sidemenu.css" rel="stylesheet">

    
    <!--Bootstrap.min css-->
    <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">

    <!-- Ansta CSS -->
    <link href="assets/css/dashboard.css" rel="stylesheet" type="text/css">

    <!-- Single-page CSS -->
    <link href="assets/plugins/single-page/css/main.css" rel="stylesheet" type="text/css">
    <!-- Data table css -->
    <link href="assets/plugins/datatable/dataTables.bootstrap4.min.css" rel="stylesheet" />
<link rel="stylesheet" href="assets/plugins/select2/select2.css">


</head>