<?php
    error_reporting(0);
   include "koneksi.php";
    $response = array();
   
$username=$_GET['username'];



     
$result = mysql_query("select wakil,id,nama,username,Foto from v_user where id_level='3'");


   

$cekquery=mysql_num_rows($result);

if ($cekquery<1) {
       $response["success"] = 0;
            $response["message"] = "kosong";
            die(json_encode($response));
    }else{
      while($sql = mysql_fetch_array($result)){
      

        $tmp = array();
       
             
        $tmp['id']         = $sql['id'];
		$tmp['nama']     = $sql['nama'];
		$tmp['wakil']     = $sql['wakil'];

		        $tmp['gambar']    = $sql['Foto'];
            $tmp["success"] = 1;
            $tmp["message"] = "ada";
                


              
        
        array_push($response, $tmp);
    }
    }
 

    header('Content-Type: application/json');
    echo json_encode($response);    
    ?>


