
<!DOCTYPE html>
<html lang="en" dir="ltr">

<!-- Mirrored from spruko.com/demo/ansta/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 18 Dec 2018 01:26:47 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
    <meta name="author" content="Creative Tim">

    <!-- Title -->
    <title>Pemilihan Kandidat
</title>
    <link href="../assets/img/brand/favicon.png" rel="icon" type="image/png">
   
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800" rel="stylesheet">

    <!-- Icons -->
    <link href="../assets/css/icons.css" rel="stylesheet">

    <!--Bootstrap.min css-->
    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css">

    <!-- Ansta CSS -->
    <link href="../assets/css/dashboard.css" rel="stylesheet" type="text/css">

    <!-- Tabs CSS -->
    <link href="../assets/plugins/tabs/style.css" rel="stylesheet" type="text/css">

    <!-- jvectormap CSS -->
    <link href="../assets/plugins/jvectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />

    <!-- Custom scroll bar css-->
    <link href="../assets/plugins/customscroll/jquery.mCustomScrollbar.css" rel="stylesheet" />

    <!-- Sidemenu Css -->
    <link href="../assets/plugins/toggle-sidebar/css/sidemenu.css" rel="stylesheet">

    
    <!--Bootstrap.min css-->
    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css">

    <!-- Ansta CSS -->
    <link href="../assets/css/dashboard.css" rel="stylesheet" type="text/css">

    <!-- Single-page CSS -->
    <link href="../assets/plugins/single-page/css/main.css" rel="stylesheet" type="text/css">
    <!-- Data table css -->
    <link href="../assets/plugins/datatable/dataTables.bootstrap4.min.css" rel="stylesheet" />
<link rel="stylesheet" href="../assets/plugins/select2/select2.css">


</head>

<?php
    error_reporting(0);
    session_start();
  include  "../config/koneksi.php";
   $nama = $_SESSION['username'];
   $user_level = $_SESSION['level'];
  

?>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>


<style type="text/css">
  #container {
  min-width: 320px;
  max-width: 600px;
  margin: 0 auto;
}
</style>
<?php
    switch($_GET[act]){
       default:
       ?>



                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box card shadow">
                                        
                                        <div class="card-body">

                                          <h2 class="mb-0">Grafik Hasil</h2>
                                           <hr/>

<div id="container"></div>


<hr/>



<?php
  $q=mysql_query("select count(a.idkandidat) as total,b.nama from votingkandidat a left join v_user b on a.idkandidat=b.id where b.id_level='3' group by a.idkandidat");

  while ($d=mysql_fetch_array($q)) {
    $a[]=$d[nama];
    $b[]=$d[total];
  }

  $c=json_encode($b);
  $d=str_replace('"', '', $c);

?>


<script type="text/javascript">
  var chart = Highcharts.chart('container', {

    title: {
        text: 'Grafik Hasil Vooting Kandidat'
    },

    subtitle: {
        text: 'Total Perolehan Suara'
    },

    xAxis: {
        categories: <?php echo json_encode($a); ?>
    },

    series: [{
        type: 'column',
        colorByPoint: true,
        data: <?php echo $d;?>,
        showInLegend: false
    }]

});


$('#plain').click(function () {
    chart.update({
        chart: {
            inverted: false,
            polar: false
        },
        subtitle: {
            text: 'Plain'
        }
    });
});

$('#inverted').click(function () {
    chart.update({
        chart: {
            inverted: true,
            polar: false
        },
        subtitle: {
            text: 'Inverted'
        }
    });
});

$('#polar').click(function () {
    chart.update({
        chart: {
            inverted: false,
            polar: true
        },
        subtitle: {
            text: 'Polar'
        }
    });
});



</script>











<?php
  $qe=mysql_query("select count(a.idkandidat) as total,c.Fakultas as nama from votingkandidat a left join v_user
 b on a.userpilih=b.username
left join fakultas c on b.id_fakultas=c.id_fakultas
  where b.id_level='2' group by c.id_fakultas");

  while ($d=mysql_fetch_array($qe)) {
    $aa[]=$d[nama];
    $bb[]=$d[total];
  }

  $cc=json_encode($bb);
  $dd=str_replace('"', '', $cc);

?>


<script type="text/javascript">
  var chart = Highcharts.chart('container2', {

    title: {
        text: 'Grafik Hasil Vooting Kandidat'
    },

    subtitle: {
        text: 'Total Perolehan Suara'
    },

    xAxis: {
        categories: <?php echo json_encode($aa); ?>
    },

    series: [{
        type: 'column',
        colorByPoint: true,
        data: <?php echo $dd;?>,
        showInLegend: false
    }]

});


$('#plain2').click(function () {
    chart.update({
        chart: {
            inverted: false,
            polar: false
        },
        subtitle: {
            text: 'Plain'
        }
    });
});

$('#inverted2').click(function () {
    chart.update({
        chart: {
            inverted: true,
            polar: false
        },
        subtitle: {
            text: 'Inverted'
        }
    });
});

$('#polar2').click(function () {
    chart.update({
        chart: {
            inverted: false,
            polar: true
        },
        subtitle: {
            text: 'Polar'
        }
    });
});

</script>





<?php
}



