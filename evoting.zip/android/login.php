<?php 
session_start(); 
error_reporting(0);
include "koneksi.php";
$username=$_POST['Login'];
$password=$_POST['Password'];


if(!empty($username&&$password)){
	$select = mysql_query("SELECT * from user  WHERE username='$username' and `password`=md5('$password') and id_level='2' limit 1");
	$sql = mysql_fetch_array($select);
	if(empty($sql)){
		$response["success"] = 0;
		$response["message"] = "User Atau Password Mungkin Salah!";
		die(json_encode($response));
  
	}else{
		
		$response['level']        = $sql['id_level'];
		$response['id'] 		  = $sql['id'];
		$response["success"]      = 1;
		$response["message"]      = "Login Berhasil";
		die(json_encode($response));
      
	}
}
         

?>
