<?php 
session_start(); 
error_reporting(0);
include "koneksi.php";
$username=$_POST['username'];
$idkandidat=$_POST['idkandidat'];

$tgl=date('Y-m-d');
if(!empty($username&&$idkandidat)){
	$select = mysql_query("SELECT * from votingkandidat  WHERE userpilih='$username' and `Tanggal`='$tgl' ");

	$cek=mysql_num_rows($select);
	if ($cek==0) {
			mysql_query("INSERT INTO `votingkandidat`( `idkandidat`, `userpilih`, `TanggalBuat`, `Tanggal`) VALUES ('$idkandidat','$username',NOW(),'$tgl')");

		$response["success"]      = 1;
		$response["message"]      = "Kandidat Berhasil Dipilih";
		die(json_encode($response));
	}else{
		$response["success"] = 2;
		$response["message"] = "Anda sudah memilih kandidat";
		die(json_encode($response));
	}



}else{
	$response["success"] = 3;
		$response["message"] = "Gagal simpan!";
		die(json_encode($response));
}
         

?>
