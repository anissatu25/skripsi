<?php
session_start();
error_reporting(0);
// if ($_GET[admin]=="y") {
	
// if (isset($_SESSION[level])) {
// 	 echo " <script>window.location.href='media.php?module=home'</script> ";
// }else{
include "atas.php" ;
include "login.php"; 

// }
// }else{

// echo "<meta http-equiv='refresh' content='0;url=http://localhost/penjualanbaju/frontend/media.php?module=home'>";


// }

?>
