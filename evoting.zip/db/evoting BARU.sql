-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2020 at 02:30 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evoting`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama` varchar(35) NOT NULL DEFAULT '',
  `alamat` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(13) NOT NULL DEFAULT '',
  `username` varchar(45) NOT NULL DEFAULT '',
  `password` varchar(45) NOT NULL DEFAULT '',
  `id_level` varchar(5) NOT NULL DEFAULT '',
  `NA` varchar(5) NOT NULL DEFAULT '',
  `TanggalBuat` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Email` varchar(45) NOT NULL,
  `gcm` varchar(255) NOT NULL,
  `Foto` varchar(45) NOT NULL DEFAULT '',
  `ktp` varchar(45) NOT NULL,
  `wakil` varchar(45) NOT NULL,
  `ktp2` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `alamat`, `phone`, `username`, `password`, `id_level`, `NA`, `TanggalBuat`, `Email`, `gcm`, `Foto`, `ktp`, `wakil`, `ktp2`) VALUES
(1, 'Panitia', 'Jember', '085123456711', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1', 'N', '0000-00-00 00:00:00', '', '', '', '', '', ''),
(17, 'lukman', 'Jember', '0912', 'lukman', 'b5bbc8cf472072baffe920e4e28ee29c', '2', '', '2019-04-04 18:53:58', '', '', '', '1232', '', ''),
(18, 'Mahasiswa', 'Jember', '20392132', 'mahasiswa', '5787be38ee03a9ae5360f54d9026465f', '2', '', '2019-04-04 18:56:34', '', '', '', '324', '', ''),
(19, 'Moh Lukman Sholeh S.Kom', 'Jember', '12345', 'kandidat', 'a94994c1f9d6c72599542b12d771d1bc', '3', '', '2019-04-04 19:04:43', '', '', '21.jpg', '32434', 'fsdfdfd', '43234'),
(20, 'David Heriwanto M.Kom', 'Jember', '1232', 'kandidat2', '2bffe16305577d9689a200067b878f65', '3', '', '2019-04-04 19:38:27', '', '', '6.jpg', '54654', 'ytfhg', '5465');

-- --------------------------------------------------------

--
-- Table structure for table `user_level`
--

CREATE TABLE `user_level` (
  `id` int(10) UNSIGNED NOT NULL,
  `level` varchar(45) NOT NULL DEFAULT '',
  `NA` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_level`
--

INSERT INTO `user_level` (`id`, `level`, `NA`) VALUES
(1, 'Panitia', 'N'),
(2, 'Pemilih', 'N'),
(3, 'Kandidat', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `votingkandidat`
--

CREATE TABLE `votingkandidat` (
  `id` int(10) UNSIGNED NOT NULL,
  `idkandidat` varchar(45) NOT NULL DEFAULT '',
  `TanggalBuat` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `userpilih` varchar(45) NOT NULL DEFAULT '',
  `Tanggal` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votingkandidat`
--

INSERT INTO `votingkandidat` (`id`, `idkandidat`, `TanggalBuat`, `userpilih`, `Tanggal`) VALUES
(1, '19', '2019-04-04 21:39:24', 'lukman', '2019-04-04'),
(2, '20', '2019-04-04 21:39:24', 'mahasiswa', '2019-04-04'),
(3, '19', '2019-04-28 19:21:03', 'lukman', '2019-04-28'),
(4, '20', '2020-01-03 22:00:10', 'lukman', '2020-01-03');

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_user`
-- (See below for the actual view)
--
CREATE TABLE `v_user` (
`wakil` varchar(45)
,`ktp2` varchar(45)
,`ktp` varchar(45)
,`id` int(10) unsigned
,`nama` varchar(35)
,`Foto` varchar(45)
,`alamat` varchar(255)
,`phone` varchar(13)
,`username` varchar(45)
,`password` varchar(45)
,`id_level` varchar(5)
,`NA` varchar(5)
,`TanggalBuat` datetime
,`Email` varchar(45)
,`gcm` varchar(255)
,`NamaLevel` varchar(45)
);

-- --------------------------------------------------------

--
-- Structure for view `v_user`
--
DROP TABLE IF EXISTS `v_user`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_user`  AS  select `a`.`wakil` AS `wakil`,`a`.`ktp2` AS `ktp2`,`a`.`ktp` AS `ktp`,`a`.`id` AS `id`,`a`.`nama` AS `nama`,`a`.`Foto` AS `Foto`,`a`.`alamat` AS `alamat`,`a`.`phone` AS `phone`,`a`.`username` AS `username`,`a`.`password` AS `password`,`a`.`id_level` AS `id_level`,`a`.`NA` AS `NA`,`a`.`TanggalBuat` AS `TanggalBuat`,`a`.`Email` AS `Email`,`a`.`gcm` AS `gcm`,`b`.`level` AS `NamaLevel` from (`user` `a` left join `user_level` `b` on((`a`.`id_level` = `b`.`id`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_level`
--
ALTER TABLE `user_level`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `votingkandidat`
--
ALTER TABLE `votingkandidat`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `user_level`
--
ALTER TABLE `user_level`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `votingkandidat`
--
ALTER TABLE `votingkandidat`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
